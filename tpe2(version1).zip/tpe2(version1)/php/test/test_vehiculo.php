<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";


//http://localhost/objetos/tpe2(version1)/php/test/test_vehiculo.php


echo "<h1> Test TP Entregable 2 - Concesionaria </h1><br>";


/*
// TEST A MODO DE PRUEBA INICIAL (Salida correcta)
echo "<h2>-- Test Auto --</h2><br>";
echo "-- Auto 1 --<br><br>";
$auto1=new Auto("Peugeot", "407", 50000, "4");
echo $auto1."<br><br>";
*/


?>
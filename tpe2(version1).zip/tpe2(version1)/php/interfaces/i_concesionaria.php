<?php

interface I_Concesionaria{

    public function listar(): string;
    public function mayorPrecio(): float;
    public function menorPrecio(): float;
    public function ordenNatural(): string;
    public function ordenPrecio(): float;
    public function contieneY(): string;

}
?>
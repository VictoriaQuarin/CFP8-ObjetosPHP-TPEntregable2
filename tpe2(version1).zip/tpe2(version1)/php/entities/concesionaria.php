<?php
require_once "../entities/concesionaria.php";
require_once "../interfaces/i_concesionaria.php";


abstract class Concesionaria implements I_Concesionaria{


/*  DUDAS SOBRE EL DESARROLLO (del contenido de la clase Concesionaria).
    ¿Debería incluir?

        1) Atributo privado 'vehiculos' (que contendrá la lista de los vehículos).
        Inicialmente debe ser cero/vacío.

        2) public function agregarVehículo() (para agregar los registros al atributo 'vehículos' 
        y así formar una lista que contenga los vehículos planteados en la consigna). 

        3) Sobreescritura de los métodos consignados en la interface.
        Es decir, plantear de forma específica para clase Concesionaria los siguientes métodos:
            listar(), mayorPrecio(), menorPrecio(), ordenNatural(), ordenPrecio(), contieneY(). 
*/


}
?>
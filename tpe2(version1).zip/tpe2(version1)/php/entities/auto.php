<?php
require_once "../entities/auto.php";

class Auto extends Vehiculo{
    private $puertas;


    public function __construct(string $marca, string $modelo, float $precio, int $puertas){
        parent::__construct($marca, $modelo, $precio);
        $this->puertas = $puertas;
    }


    public function __tostring(): string{
        return parent::__tostring().",".$this->puertas;
    }


/*  -- Consideraciones sobre Constructores --
    Fuente - https://www.php.net/manual/es/language.oop5.decon.php 

PHP permite a los desarrolladores declarar métodos constructores para las clases. 
Aquellas que tengan un método constructor lo invocarán en cada nuevo objeto creado, lo que lo hace idóneo para
cualquier inicialización que el objeto pueda necesitar antes de ser usado.

--> NOTA: Los constructores padres NO son llamados implícitamente, si la clase hija define un constructor. 
Para ejecutar un constructor padre, se requiere invocar a parent::__construct() desde el constructor hijo. 
Si el hijo no define un constructor, entonces se puede heredar de la clase madre como un método de clase normal 
(si no fue declarada como privada). 
*/

}
?>
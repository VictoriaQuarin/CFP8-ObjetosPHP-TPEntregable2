<?php
require_once "../entities/moto.php";

class Moto extends Vehiculo{
    private $cilindrada;


    public function __construct(string $marca, string $modelo, float $precio, int $cilindrada){
        parent::__construct($marca, $modelo, $precio);
        $this->cilindrada = $cilindrada;
    }


    public function __tostring(): string{
        return parent::__tostring().",".$this->cilindrada;
    }
    
}
?>
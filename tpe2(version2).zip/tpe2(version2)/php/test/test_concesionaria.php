<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";


//http://localhost/objetos/tpe2(version2)/php/test/test_concesionaria.php


echo "<h1> Test TP Entregable 2 - Concesionaria </h1><br>";





?>
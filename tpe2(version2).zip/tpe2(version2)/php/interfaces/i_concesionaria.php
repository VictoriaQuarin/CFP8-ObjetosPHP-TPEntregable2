<?php

interface I_Concesionaria{

    public function listar() : {};
    public function mayorPrecio() : {};
    public function menorPrecio() : {};
    public function ordenNatural() : {};
    public function ordenPrecio() : {};
    public function contieneY() : {};

}
?>
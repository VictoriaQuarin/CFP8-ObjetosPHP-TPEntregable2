<?php
require_once "../entities/concesionaria.php";
require_once "../interfaces/i_concesionaria.php";


class Concesionaria implements I_Concesionaria{

    private $vehiculos = [];



    public function listar() : {};

    public function mayorPrecio() : {};

    public function menorPrecio() : {};

    public function ordenNatural() : {};

    public function ordenPrecio() : {};

    public function contieneY() : {};



    public function agregarVehiculo(Vehiculo $vehiculo){
        $this->vehiculos[] = $vehiculo;
    }


}
?>